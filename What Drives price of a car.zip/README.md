Practical Application Assignment 11.1

Vehicles.csv data file is used for this application. This dataset is sourced from Kaggle
Graphs are placed in images folder
CRISP-DM Methodology is used, and followed all the steps from this Methodology

Project Objective
    Understand what factors make a car more or less expensive. 
    As a result of your analysis, you should provide clear recommendations to your client [a used car dealership] as to what consumers value in a used car.
    Provide recommendations from your findings to the dealership

Business Understanding
      The business problem can be defined as predicting the price of used cars based on various attributes provided in the dataset. 
      This involves understanding the factors (or key drivers) that influence the pricing of used cars in different regions and under different conditions.
      Key Drivers for Used Car Prices in the given dataset and business definitions for each of these are as below:
            1.	Year: Generally, newer cars tend to have higher prices.
            2.	Manufacturer and Model: Some brands and models hold higher resale value due to reputation, reliability, or desirability.
            3.	Condition: The state of the car (e.g., excellent, good, fair) affects its price.
            4.	Odometer: Lower mileage typically correlates with a higher price.
            5.	Title Status: Cars with a clean title often fetch higher prices.
            6.	Transmission Type: Automatic or manual transmission can affect price, with automatic typically being more popular and thus higher priced.
            7.	Drive Type: All-wheel drive or four-wheel drive vehicles often command higher prices, especially in certain regions.
            8.	Size and Type: Larger vehicles like SUVs or trucks usually have higher prices compared to smaller cars like sedans.
            9.	Fuel Type: Preferences for hybrid or electric vehicles might influence pricing trends in certain markets.
            10.	Location (Region/State): Local market conditions, economic factors, and demand can significantly impact prices.

      Technical Approach:
                To address the business problem, a regression analysis could be employed where the dependent variable is the price of the used car, 
                and the independent variables include those identified as key drivers. Techniques such as multiple linear regressionis used
                Feature engineering involves handling missing data, encoding categorical variables, and  scaling numerical features.
                The ultimate goal is to  that accurately predicts the price of a used car given its characteristics, which can help sellers optimize pricing
                In this application, condition of the car is used as the main characteristics to determine the price. Example : good cars can be priced high
  
   Data Understanding
                I looked into various aspects of raw data in the file and noticed below :
                        - The dataset had manu NaN values
                        - id, model,VIN,odometer reading has high cardinality 
                        - 4 columns have numerical values and rest all are characteristics
                        - Price is the dependent variables
                        - Noticed the key drivers in the dataset
                           Key Drivers of the data set by observation manufacturere, condition, cylinders, transmission, type, paint_color, state, year

  Data Preparation
                 - Identified and removed duplicates
                 - Created standard format for the year
                 - Cleaned up Values for Cylinder column
                       Removed non-numeric characters from 'cylinders' column and convert to numeric  
                       Replaced NaN values in 'cylinders' column with 0
                       Converted 'cylinders' column to integer type  
                 -Dropped unnecessary columns
                        'year', 'id', 'model', 'VIN', 'region','odometer', 'title_status', 'drive', 'size' 
                        Used year_new column, that was created with required formatting
                 -Dropped rows with more NaN values
                 - Converted 'type' column to string 
                

Data Exploration
                   - Created Various Visualization to analyze data 
                         Created a Scatter plot to see any outliers in the columns based on Condition and price of the Car
                         Created a histogram to study 'Distribution of Car Prices by Type. Pick up and SUV's are priced high and looks like high demand for these cars
                         Created a Box Plot to show 'Distribution of Car Prices by Condition of the car'  and a histogram to show by 'Color'. 
                         Created a histogram to show Car Prices by top 5 Manufacturers
                         Calculated Mean Price by Manufacturer and Condition of the car and created a graph to show the correlation
                         <All the graphs are stored in the images folder of the project>
                         <All visulatizations are shown end of this document>
                  - Separate features (X) and target (y)
                  - Defined categorical and numerical features
                  - Preprocessed pipeline for categorical features
                  - Created Training and Test datasets
                  - Defined numeric features (replace with your actual numeric feature names or indices)
                  - Define preprocessing steps for numeric features
                  - Created a ColumnTransformer to apply preprocessing steps to numeric features
Modeling
                   - Initialized models: Linear Regression, Ridge, and Lasso
                   - Defined pipelines for Linear, Ridge, and Lasso Regression
                   - Fitted and trained the models 
                   - Calculated Mean Squared Error for each Model
                   - Predict and evaluated the model using Linear Regression, Ridge Regression and Lasso Regression

                   Got below values
                    Linear Regression Mean Squared Error: 159170452.03
                    Ridge Regression Mean Squared Error: 159170452.33
                    Lasso Regression Mean Squared Error: 159170517.46 

                    Lasso regression shows least Mean Squared Error. Hence, this model can be deployed to find out price of the cars based on various feature
                    predictions can be done using Lasso Regression model

Evaluation         Applied Cross-Validation logic to evaluate the model and the final numbers showed same as predicted.

Deployment         Decided to use Lasso Regression model for predictions
                   Applied Lasso Regression model to predict the price of car based on condition [Only one feature used]

                    Condition = 1 - Excellent, 2 = Good '
                    For a good car predicted price  = $17,325

Recommendation to the Dealer :
                   Based on our Analysis and Predictive model created, the price of the car depends on the 
                      - Condition of the Car :  Good condition cars though expensive, are preferred by customers and hence, they must increase the inventory of these cars
                      - There is a demand for Brand value, as the sale for luxury cars was more, hence the dealer must keep more of these cars
                      -  Prices of good cars will go up, as predicted, hence the dealer must have more good cars in their inventory




 
